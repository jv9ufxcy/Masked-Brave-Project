Here is where the Tiled2Unity Utility will export *.tiled2unity.xml files to.

Unity scripts in the Tiled2Unity namespace will import these files and from 
them create the meshes, textures, materials, and prefabs needed to place 
your Tiled maps in Unity scenes.

